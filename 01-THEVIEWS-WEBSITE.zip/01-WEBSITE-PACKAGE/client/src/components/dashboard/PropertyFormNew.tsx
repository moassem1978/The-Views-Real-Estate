import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Property } from "../../types";
import { apiRequest } from "../../lib/queryClient";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Card, CardContent } from "@/components/ui/card";
import { Loader2, Upload, X } from "lucide-react";
import { useForm } from "react-hook-form";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";

interface PropertyFormProps {
  propertyId?: number;
  onSuccess?: () => void;
  onCancel?: () => void;
}

export default function PropertyForm({
  propertyId,
  onSuccess,
  onCancel,
}: PropertyFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [images, setImages] = useState<File[]>([]);
  const [existingImages, setExistingImages] = useState<string[]>([]);
  const [uploading, setUploading] = useState(false);
  const [previewVisible, setPreviewVisible] = useState(false);
  const [previewImage, setPreviewImage] = useState('');
  const [imagePreviewModal, setImagePreviewModal] = useState(false);
  const [currentPreviewIndex, setCurrentPreviewIndex] = useState(0);
  const [imagesToDelete, setImagesToDelete] = useState<number[]>([]);
  const [imagesToReplace, setImagesToReplace] = useState<Map<number, File>>(new Map());
  const isEditing = !!propertyId;

  // Form definition with default values
  const form = useForm({
    defaultValues: {
      title: "",
      description: "",
      city: "",
      state: "",
      projectName: "",
      developerName: "",
      propertyType: "",
      listingType: "Primary",
      // Removed reference field
      price: 0,
      downPayment: 0,
      installmentAmount: 0,
      installmentPeriod: 0,
      bedrooms: 0,
      bathrooms: 0,
      builtUpArea: 0,
      plotSize: 0,
      gardenSize: 0, 
      floor: 0,
      isFeatured: false,
      isNewListing: true,
      isHighlighted: false,
      isGroundUnit: false,
      isFullCash: false,
      country: "Egypt",
    }
  });

  // Fetch available projects for dropdown
  const { data: projects } = useQuery({
    queryKey: ["/api/projects"],
    enabled: true,
  });

  // Fetch property data if in edit mode
  const {
    data: propertyData,
    isLoading: isLoadingProperty,
    error: propertyError,
  } = useQuery<Property>({
    queryKey: [`/api/properties/${propertyId || 0}`],
    enabled: isEditing && !!propertyId,
  });

  // Update form when property data is loaded
  useEffect(() => {
    if (isEditing && propertyData) {
      // CRITICAL FIX: Enhanced handling of existing images
      console.log("Checking existing images in property data:", propertyData.images);

      if (propertyData.images) {
        try {
          // Try to handle various image field formats
          if (Array.isArray(propertyData.images)) {
            // Already an array, use it directly
            console.log(`Found ${propertyData.images.length} images as array`);
            setExistingImages(propertyData.images);
          } else if (typeof propertyData.images === 'string') {
            // String format could be JSON or comma-separated
            if (propertyData.images.includes('[') || propertyData.images.includes('{')) {
              // Likely JSON string, try to parse
              try {
                const parsedImages = JSON.parse(propertyData.images);
                if (Array.isArray(parsedImages)) {
                  console.log(`Parsed ${parsedImages.length} images from JSON string`);
                  setExistingImages(parsedImages);
                } else {
                  // Parsed but not an array - might be an object with image values
                  console.log("Parsed JSON but got non-array result:", parsedImages);
                  const imageValues = typeof parsedImages === 'object' ? 
                                     Object.values(parsedImages).filter(Boolean) : 
                                     [parsedImages].filter(Boolean);
                  console.log(`Extracted ${imageValues.length} images from parsed JSON`);
                  setExistingImages(imageValues);
                }
              } catch (e) {
                console.error("Failed to parse image JSON:", e);
                // Fallback - treat as comma-separated
                if (propertyData.images.includes(',')) {
                  const imageArray = propertyData.images.split(',').map(img => img.trim()).filter(Boolean);
                  console.log(`Split string into ${imageArray.length} comma-separated images`);
                  setExistingImages(imageArray);
                } else {
                  // Single image string
                  console.log("Using single image string");
                  setExistingImages([propertyData.images.trim()]);
                }
              }
            } else if (propertyData.images.includes(',')) {
              // Simple comma-separated list
              const imageArray = propertyData.images.split(',').map(img => img.trim()).filter(Boolean);
              console.log(`Split string into ${imageArray.length} comma-separated images`);
              setExistingImages(imageArray);
            } else if (propertyData.images.trim()) {
              // Single image URL
              console.log("Using single image URL");
              setExistingImages([propertyData.images.trim()]);
            }
          }
        } catch (error) {
          console.error("Error processing existing images:", error);
          setExistingImages([]);
        }
      } else {
        console.log("No existing images found");
        setExistingImages([]);
      }

      // Update form values with property data
      console.log("Loading property data for editing:", propertyData);

      form.reset({
        title: propertyData.title || "",
        description: propertyData.description || "",
        city: propertyData.city || "",
        state: propertyData.state || "",
        projectName: propertyData.projectName || "",
        developerName: propertyData.developerName || "",
        propertyType: propertyData.propertyType || "",
        listingType: propertyData.listingType || "Primary",
        // Reference field completely removed
        price: propertyData.price || 0,
        downPayment: propertyData.downPayment || 0,
        installmentAmount: propertyData.installmentAmount || 0,
        installmentPeriod: propertyData.installmentPeriod || 0,
        bedrooms: propertyData.bedrooms || 0,
        bathrooms: propertyData.bathrooms || 0,
        builtUpArea: propertyData.builtUpArea || 0,
        plotSize: propertyData.plotSize || 0,
        gardenSize: propertyData.gardenSize || 0,
        floor: propertyData.floor || 0,
        isFeatured: propertyData.isFeatured || false,
        isNewListing: propertyData.isNewListing || false,
        isHighlighted: propertyData.isHighlighted || false,
        isGroundUnit: propertyData.isGroundUnit || false,
        isFullCash: propertyData.isFullCash || false,
        country: propertyData.country || "Egypt",
      });
    }
  }, [isEditing, propertyData, form]);

  // Set up scroll handler for modal
  useEffect(() => {
    // Ensure modal content is scrollable
    const modalContent = document.querySelector('[role="dialog"]');
    if (modalContent) {
      modalContent.classList.add('modal-scrollable');
    }
    return () => {
      if (modalContent) {
        modalContent.classList.remove('modal-scrollable');
      }
    };
  }, []);

  // Enhanced image change handlers with explicit management
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      // Add new files to the existing ones instead of replacing them
      const newFiles = Array.from(e.target.files as FileList);
      setImages(prevImages => [...prevImages, ...newFiles]);

      // Reset the file input to allow selecting more files later
      e.target.value = '';
    }
  };

  // Open image preview modal with navigation
  const openImagePreview = (imageIndex: number, isExisting: boolean = false) => {
    setCurrentPreviewIndex(imageIndex);
    setImagePreviewModal(true);
    
    if (isExisting && existingImages[imageIndex]) {
      setPreviewImage(existingImages[imageIndex]);
    } else if (!isExisting && images[imageIndex]) {
      setPreviewImage(URL.createObjectURL(images[imageIndex]));
    }
  };

  // Close image preview modal
  const closeImagePreview = () => {
    setImagePreviewModal(false);
    setPreviewImage('');
  };

  // Navigate through images in preview
  const navigatePreview = (direction: 'prev' | 'next') => {
    const totalExisting = existingImages.length;
    const totalNew = images.length;
    const totalImages = totalExisting + totalNew;
    
    let newIndex = currentPreviewIndex;
    if (direction === 'next') {
      newIndex = (currentPreviewIndex + 1) % totalImages;
    } else {
      newIndex = currentPreviewIndex === 0 ? totalImages - 1 : currentPreviewIndex - 1;
    }
    
    setCurrentPreviewIndex(newIndex);
    
    // Update preview image
    if (newIndex < totalExisting) {
      setPreviewImage(existingImages[newIndex]);
    } else {
      const newImageIndex = newIndex - totalExisting;
      setPreviewImage(URL.createObjectURL(images[newImageIndex]));
    }
  };

  // Remove a selected new image before upload
  const removeSelectedImage = (index: number) => {
    setImages(prevImages => {
      const newImages = [...prevImages];
      newImages.splice(index, 1);
      return newImages;
    });
  };

  // Mark existing image for deletion (don't remove immediately)
  const markImageForDeletion = (index: number) => {
    setImagesToDelete(prev => [...prev, index]);
  };

  // Unmark image for deletion
  const unmarkImageForDeletion = (index: number) => {
    setImagesToDelete(prev => prev.filter(i => i !== index));
  };

  // Replace an existing image
  const replaceExistingImage = (index: number, file: File) => {
    setImagesToReplace(prev => new Map(prev.set(index, file)));
  };

  // Handle file input for replacing specific image
  const handleReplaceImage = (index: number) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        replaceExistingImage(index, file);
      }
    };
    input.click();
  };

  // Create/Update property mutation
  const mutation = useMutation({
    mutationFn: async (data: Partial<Property>) => {
      if (isEditing) {
        return await apiRequest("PUT", `/api/properties/${propertyId}`, data);
      } else {
        return await apiRequest("POST", "/api/properties", data);
      }
    },
    onSuccess: () => {
      // Invalidate properties queries
      queryClient.invalidateQueries({ queryKey: ["/api/properties"] });

      if (isEditing) {
        queryClient.invalidateQueries({ queryKey: [`/api/properties/${propertyId}`] });
      }
    },
  });

  // Handle form submission
  const onSubmit = async (data: any) => {
    try {
      // Handle "none" placeholder values correctly
      // Replace "none" placeholder values with appropriate defaults
      if (data.city === "none") {
        data.city = "";
      }
      
      if (data.country === "none") {
        data.country = "";
      }
      
      if (data.propertyType === "none") {
        data.propertyType = "";
      }
      
      if (data.listingType === "none") {
        data.listingType = "";
      }
      
      if (data.projectName === "none") {
        data.projectName = "";
      }

      // Ensure state matches city if not already set
      if (!data.state && data.city) {
        data.state = data.city;
      }

      // Backend requires an address - use project name as address if not provided
      if (!data.address && data.projectName) {
        data.address = data.projectName;
      }

      // CRITICAL FIX: Improved handling of property type
      if (data.propertyType && data.propertyType.trim() && data.propertyType !== "none") {
        // Normalize propertyType to lowercase for consistency
        data.propertyType = data.propertyType.trim().toLowerCase();
        console.log(`Using normalized property type: ${data.propertyType}`);
      } else {
        // Default to apartment if no property type is provided
        console.log("WARNING: Property type not set! Setting default to apartment");
        data.propertyType = "apartment"; 
      }

      // Ensure we have a valid property type from our standard list
      const validPropertyTypes = ["apartment", "penthouse", "chalet", "twinhouse", "villa", "office", "townhouse"];
      if (!validPropertyTypes.includes(data.propertyType)) {
        console.log(`WARNING: Invalid property type "${data.propertyType}", defaulting to apartment`);
        data.propertyType = "apartment";
      }

      console.log(`Final property type being sent: ${data.propertyType}`);

      // Ensure listingType is included 
      if (!data.listingType) {
        data.listingType = "Primary";
      }

      // Reference field completely removed - no reference, references, or reference_number

      console.log("Sending property data:", {
        city: data.city,
        propertyType: data.propertyType,
        listingType: data.listingType,
        developerName: data.developerName
      });

      // Step 1: Save property data first
      const response = await mutation.mutateAsync(data);
      const property = await response.json();

      // Get the property ID (either from the saved property or existing ID)
      const savedPropertyId = isEditing ? propertyId : property.id;

      // Step 2: Handle explicit image changes
      try {
        setUploading(true);
        
        // Start with existing images, apply deletions and replacements
        let finalImages = [...existingImages];
        
        // Remove images marked for deletion (in reverse order to maintain indices)
        const sortedDeletions = [...imagesToDelete].sort((a, b) => b - a);
        sortedDeletions.forEach(index => {
          if (index < finalImages.length) {
            console.log(`Removing image at index ${index}: ${finalImages[index]}`);
            finalImages.splice(index, 1);
          }
        });
        
        // Handle image replacements
        if (imagesToReplace.size > 0) {
          console.log(`Processing ${imagesToReplace.size} image replacements`);
          
          for (const [originalIndex, newFile] of Array.from(imagesToReplace.entries())) {
            // Adjust index based on deletions that occurred before this index
            const adjustedIndex = originalIndex - imagesToDelete.filter(delIndex => delIndex < originalIndex).length;
            
            if (adjustedIndex >= 0 && adjustedIndex < finalImages.length) {
              // Upload the replacement image
              const formData = new FormData();
              formData.append('images', newFile);
              formData.append('propertyId', savedPropertyId.toString());
              
              const response = await fetch(`/api/upload/property-images-direct`, {
                method: 'POST',
                body: formData,
              });
              
              if (response.ok) {
                const uploadResult = await response.json();
                const newImageUrl = uploadResult.imageUrls?.[0] || uploadResult.fileUrls?.[0];
                
                if (newImageUrl) {
                  console.log(`Replacing image at index ${adjustedIndex} with: ${newImageUrl}`);
                  finalImages[adjustedIndex] = newImageUrl;
                }
              }
            }
          }
        }
        
        // Handle new image uploads
        if (images.length > 0) {
          console.log(`Uploading ${images.length} new images for property ${savedPropertyId}`);

          const formData = new FormData();
          formData.append('propertyId', savedPropertyId.toString());

          images.forEach((image, idx) => {
            console.log(`Adding new image ${idx + 1}/${images.length}: ${image.name} (${Math.round(image.size/1024)}KB)`);
            formData.append('images', image);
          });

          const response = await fetch(`/api/upload/property-images-direct`, {
            method: 'POST',
            body: formData,
          });

          if (!response.ok) {
            const errorText = await response.text();
            console.error(`New image upload failed with status ${response.status}:`, errorText);
            throw new Error(`New image upload failed with status: ${response.status} - ${errorText}`);
          }

          const uploadResult = await response.json();
          const newImageUrls = uploadResult.imageUrls || uploadResult.fileUrls || [];
          console.log(`Uploaded ${newImageUrls.length} new images successfully:`, newImageUrls);
          
          // Add new images to the final list
          finalImages.push(...newImageUrls);
        }

        // Ensure all images have the correct path format
        const formattedImages = finalImages.map(img => {
          if (typeof img === 'string' && !img.startsWith('/') && !img.startsWith('http')) {
            return `/${img}`;
          }
          return img;
        }).filter(Boolean);

        console.log(`Final image list for property ${savedPropertyId}:`, formattedImages);

        // Update property with the final image list
        const updateResponse = await apiRequest("PATCH", `/api/properties/${savedPropertyId}`, {
          images: formattedImages
        });

        if (!updateResponse.ok) {
          throw new Error(`Property image update failed with status: ${updateResponse.status}`);
        }

        console.log(`Successfully updated property ${savedPropertyId} with ${formattedImages.length} images`);
        
        // Reset image change tracking
        setImagesToDelete([]);
        setImagesToReplace(new Map());
        setImages([]);
        
      } catch (error) {
        console.error("Error processing image changes:", error);
        toast({
          variant: "destructive",
          title: "Error updating property images",
          description: error instanceof Error ? error.message : "Failed to update property images"
        });
        return; // Don't close the form on error
      } finally {
        setUploading(false);
      }

      // Invalidate and refetch queries to ensure UI reflects changes
      await queryClient.invalidateQueries({ queryKey: ["/api/properties"] });
      if (isEditing) {
        await queryClient.invalidateQueries({ queryKey: [`/api/properties/${propertyId}`] });
      }
      
      // Force a refetch to ensure data is current
      await queryClient.refetchQueries({ queryKey: ["/api/properties"] });
      
      // Success notification
      toast({
        title: isEditing ? "Property updated" : "Property created",
        description: "Your property has been saved successfully.",
        variant: "default"
      });

      // Only close the form after all operations have completed successfully
      if (onSuccess) {
        // Small delay to ensure toast is visible and data is refreshed
        setTimeout(() => {
          onSuccess();
        }, 1000);
      }

    } catch (error) {
      console.error("Form submission error:", error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to save property",
        variant: "destructive"
      });
    }
  };

  // Show loading state
  if (isLoadingProperty && isEditing) {
    return (
      <div className="flex justify-center items-center h-96">
        <Loader2 className="h-8 w-8 animate-spin text-[#B87333]" />
      </div>
    );
  }

  // Show error state 
  if (propertyError && isEditing) {
    return (
      <div className="flex flex-col justify-center items-center h-96 space-y-4">
        <div className="text-destructive text-center">
          <h3 className="text-lg font-medium">Error Loading Property</h3>
          <p>{propertyError instanceof Error ? propertyError.message : "Failed to load property details"}</p>
        </div>
        <Button variant="outline" onClick={onCancel}>Go Back</Button>
      </div>
    );
  }

  // Render form
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8 overflow-y-auto max-h-[80vh]">
        {/* Form header with buttons */}
        <div className="flex justify-between items-center sticky top-0 bg-white z-10 pb-4 border-b">
          <h2 className="text-xl font-semibold">{isEditing ? "Edit Property" : "Add New Property"}</h2>
          <div className="flex gap-2">
            {onCancel && (
              <Button type="button" variant="outline" onClick={onCancel}>
                Cancel
              </Button>
            )}
            <Button 
              type="submit" 
              disabled={mutation.isPending || uploading}
              className="bg-[#B87333] hover:bg-[#9e612c] text-white"
            >
              {(mutation.isPending || uploading) && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {isEditing ? "Update Property" : "Create Property"}
            </Button>
          </div>
        </div>

        {/* Main form content */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Left column */}
          <div className="space-y-4">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Title*</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter property title" {...field} required />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Reference number field removed */}

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description*</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Enter property description" 
                      className="min-h-[120px]"
                      {...field} 
                      required 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="city"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>City*</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select city" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="none">Select a city</SelectItem>
                        <SelectItem value="Cairo">Cairo</SelectItem>
                        <SelectItem value="Zayed">Zayed/6th October</SelectItem>
                        <SelectItem value="North coast">North Coast</SelectItem>
                        <SelectItem value="Red Sea">Red Sea</SelectItem>
                        <SelectItem value="Dubai">Dubai</SelectItem>
                        <SelectItem value="London">London</SelectItem>
                        <SelectItem value="Other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="country"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Country</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select country" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="none">Select a country</SelectItem>
                        <SelectItem value="Egypt">Egypt</SelectItem>
                        <SelectItem value="UAE">UAE</SelectItem>
                        <SelectItem value="UK">UK</SelectItem>
                        <SelectItem value="Other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="projectName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Project Name*</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter project name" {...field} required />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="developerName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Developer Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter developer name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="propertyType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Property Type*</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="none">Select a property type</SelectItem>
                        <SelectItem value="apartment">Apartment</SelectItem>
                        <SelectItem value="penthouse">Penthouse</SelectItem>
                        <SelectItem value="villa">Villa</SelectItem>
                        <SelectItem value="twinhouse">Twinhouse</SelectItem>
                        <SelectItem value="townhouse">Townhouse</SelectItem>
                        <SelectItem value="chalet">Chalet</SelectItem>
                        <SelectItem value="office">Office</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="listingType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Listing Type*</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="none">Select a listing type</SelectItem>
                        <SelectItem value="Primary">Primary</SelectItem>
                        <SelectItem value="Resale">Resale</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="bedrooms"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Bedrooms*</FormLabel>
                    <FormControl>
                      <Input type="number" {...field} 
                        onChange={(e) => field.onChange(Number(e.target.value))} 
                        required 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="bathrooms"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Bathrooms*</FormLabel>
                    <FormControl>
                      <Input type="number" {...field} 
                        onChange={(e) => field.onChange(Number(e.target.value))} 
                        required 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </div>

          {/* Right column */}
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="price"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Price (L.E)*</FormLabel>
                    <FormControl>
                      <Input type="number" {...field} 
                        onChange={(e) => field.onChange(Number(e.target.value))} 
                        required 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="builtUpArea"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Built-up Area (m²)*</FormLabel>
                    <FormControl>
                      <Input type="number" {...field} 
                        onChange={(e) => field.onChange(Number(e.target.value))} 
                        required 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Show payment details for Primary properties */}
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="downPayment"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Down Payment (L.E)</FormLabel>
                    <FormControl>
                      <Input type="number" {...field} 
                        onChange={(e) => field.onChange(Number(e.target.value))} 
                      />
                    </FormControl>
                    <FormDescription>
                      For primary listings
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="installmentPeriod"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Installment Period (months)</FormLabel>
                    <FormControl>
                      <Input type="number" {...field} 
                        onChange={(e) => field.onChange(Number(e.target.value))} 
                      />
                    </FormControl>
                    <FormDescription>
                      For primary listings
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="plotSize"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Plot Size (m²)</FormLabel>
                    <FormControl>
                      <Input type="number" {...field} 
                        onChange={(e) => field.onChange(Number(e.target.value))} 
                      />
                    </FormControl>
                    <FormDescription>
                      For villas and townhouses
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="gardenSize"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Garden Size (m²)</FormLabel>
                    <FormControl>
                      <Input type="number" {...field} 
                        onChange={(e) => field.onChange(Number(e.target.value))} 
                      />
                    </FormControl>
                    <FormDescription>
                      For ground floor units
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="floor"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Floor Number</FormLabel>
                    <FormControl>
                      <Input type="number" {...field} 
                        onChange={(e) => field.onChange(Number(e.target.value))} 
                      />
                    </FormControl>
                    <FormDescription>
                      For apartments
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Property flags section */}
            <Card className="mt-4">
              <CardContent className="pt-4 grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="isFeatured"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                      <div className="space-y-0.5">
                        <FormLabel>Featured Property</FormLabel>
                        <FormDescription>
                          Show on homepage
                        </FormDescription>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="isNewListing"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                      <div className="space-y-0.5">
                        <FormLabel>New Listing</FormLabel>
                        <FormDescription>
                          Mark as newly added
                        </FormDescription>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="isHighlighted"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                      <div className="space-y-0.5">
                        <FormLabel>Highlighted</FormLabel>
                        <FormDescription>
                          Priority in listings
                        </FormDescription>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="isGroundUnit"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                      <div className="space-y-0.5">
                        <FormLabel>Ground Unit</FormLabel>
                        <FormDescription>
                          Has garden access
                        </FormDescription>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="isFullCash"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                      <div className="space-y-0.5">
                        <FormLabel>Full Cash</FormLabel>
                        <FormDescription>
                          No installments
                        </FormDescription>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>

            {/* Enhanced Image Management Section */}
            <div className="mt-6">
              <h3 className="text-lg font-medium mb-2">Property Images</h3>
              <p className="text-sm text-gray-600 mb-4">Click any image to preview. Make explicit changes to avoid mixing up images.</p>

              {/* Image upload button */}
              <div className="flex items-center justify-center border-2 border-dashed border-gray-300 rounded-md p-6 cursor-pointer hover:border-gray-400 transition-colors" onClick={() => document.getElementById('image-upload')?.click()}>
                <input
                  id="image-upload"
                  type="file"
                  multiple
                  accept="image/*"
                  className="hidden"
                  onChange={handleImageChange}
                />
                <div className="flex flex-col items-center text-gray-500">
                  <Upload className="h-10 w-10 mb-2" />
                  <p className="text-sm">Click or drag images here to upload</p>
                  <p className="text-xs mt-1">Maximum 10 images, 25MB each</p>
                </div>
              </div>

              {/* Existing images with enhanced controls */}
              {existingImages.length > 0 && (
                <div className="mt-4">
                  <h4 className="text-sm font-medium mb-2">Current Property Images:</h4>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {existingImages.map((image, index) => (
                      <div key={`existing-${index}`} className="relative group">
                        <div className={`relative ${imagesToDelete.includes(index) ? 'opacity-50' : ''}`}>
                          <img 
                            src={image} 
                            alt={`Property image ${index + 1}`} 
                            className="w-full h-32 object-cover rounded-md cursor-pointer hover:opacity-90 transition-opacity"
                            onClick={() => openImagePreview(index, true)}
                          />
                          
                          {/* Image overlay with actions */}
                          <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-all duration-200 rounded-md flex items-center justify-center">
                            <div className="opacity-0 group-hover:opacity-100 transition-opacity flex space-x-2">
                              <button 
                                type="button"
                                className="bg-blue-500 text-white rounded-full p-1 hover:bg-blue-600 transition-colors"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  openImagePreview(index, true);
                                }}
                                title="Preview image"
                              >
                                <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                                </svg>
                              </button>
                              
                              <button 
                                type="button"
                                className="bg-green-500 text-white rounded-full p-1 hover:bg-green-600 transition-colors"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleReplaceImage(index);
                                }}
                                title="Replace image"
                              >
                                <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
                                </svg>
                              </button>
                              
                              {imagesToDelete.includes(index) ? (
                                <button 
                                  type="button"
                                  className="bg-yellow-500 text-white rounded-full p-1 hover:bg-yellow-600 transition-colors"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    unmarkImageForDeletion(index);
                                  }}
                                  title="Undo delete"
                                >
                                  <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6l6-6" />
                                  </svg>
                                </button>
                              ) : (
                                <button 
                                  type="button"
                                  className="bg-red-500 text-white rounded-full p-1 hover:bg-red-600 transition-colors"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    markImageForDeletion(index);
                                  }}
                                  title="Mark for deletion"
                                >
                                  <X className="h-4 w-4" />
                                </button>
                              )}
                            </div>
                          </div>
                          
                          {/* Replacement indicator */}
                          {imagesToReplace.has(index) && (
                            <div className="absolute top-1 left-1 bg-green-500 text-white text-xs px-2 py-1 rounded">
                              Will Replace
                            </div>
                          )}
                          
                          {/* Deletion indicator */}
                          {imagesToDelete.includes(index) && (
                            <div className="absolute top-1 left-1 bg-red-500 text-white text-xs px-2 py-1 rounded">
                              Will Delete
                            </div>
                          )}
                        </div>
                        
                        <p className="text-xs text-gray-500 mt-1 text-center">Image {index + 1}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* New images to upload */}
              {images.length > 0 && (
                <div className="mt-4">
                  <h4 className="text-sm font-medium mb-2">New Images to Upload:</h4>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {images.map((image, index) => (
                      <div key={`new-${index}`} className="relative group">
                        <img 
                          src={URL.createObjectURL(image)} 
                          alt={`New image ${index + 1}`} 
                          className="w-full h-32 object-cover rounded-md cursor-pointer hover:opacity-90 transition-opacity"
                          onClick={() => openImagePreview(existingImages.length + index, false)}
                        />
                        <button 
                          type="button"
                          className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600 transition-colors"
                          onClick={() => removeSelectedImage(index)}
                          title="Remove image"
                        >
                          <X className="h-4 w-4" />
                        </button>
                        <p className="text-xs text-gray-500 mt-1 text-center">New {index + 1}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Change summary */}
              {(imagesToDelete.length > 0 || imagesToReplace.size > 0 || images.length > 0) && (
                <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-md">
                  <h5 className="text-sm font-medium text-blue-800 mb-2">Pending Changes:</h5>
                  <ul className="text-xs text-blue-700 space-y-1">
                    {imagesToDelete.length > 0 && (
                      <li>• {imagesToDelete.length} image(s) will be deleted</li>
                    )}
                    {imagesToReplace.size > 0 && (
                      <li>• {imagesToReplace.size} image(s) will be replaced</li>
                    )}
                    {images.length > 0 && (
                      <li>• {images.length} new image(s) will be added</li>
                    )}
                  </ul>
                </div>
              )}
            </div>

            {/* Enhanced Image Preview Modal */}
            {imagePreviewModal && (
              <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
                <div className="max-w-4xl max-h-full p-4 relative">
                  <div className="bg-white rounded-lg overflow-hidden">
                    <div className="flex justify-between items-center p-4 border-b">
                      <h3 className="text-lg font-medium">
                        Image Preview ({currentPreviewIndex + 1} of {existingImages.length + images.length})
                      </h3>
                      <button 
                        onClick={closeImagePreview}
                        className="text-gray-500 hover:text-gray-700"
                      >
                        <X className="h-6 w-6" />
                      </button>
                    </div>
                    
                    <div className="relative">
                      <img 
                        src={previewImage} 
                        alt="Preview" 
                        className="max-w-full max-h-96 mx-auto block"
                      />
                      
                      {/* Navigation buttons */}
                      {(existingImages.length + images.length) > 1 && (
                        <>
                          <button 
                            onClick={() => navigatePreview('prev')}
                            className="absolute left-2 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-50 text-white rounded-full p-2 hover:bg-opacity-75"
                          >
                            <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                            </svg>
                          </button>
                          
                          <button 
                            onClick={() => navigatePreview('next')}
                            className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-50 text-white rounded-full p-2 hover:bg-opacity-75"
                          >
                            <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                            </svg>
                          </button>
                        </>
                      )}
                    </div>
                    
                    <div className="p-4 border-t bg-gray-50">
                      <div className="flex justify-between items-center">
                        <div className="text-sm text-gray-600">
                          {currentPreviewIndex < existingImages.length ? 
                            `Current Property Image ${currentPreviewIndex + 1}` : 
                            `New Image ${currentPreviewIndex - existingImages.length + 1}`
                          }
                        </div>
                        
                        <div className="flex space-x-2">
                          {currentPreviewIndex < existingImages.length && (
                            <>
                              <button 
                                onClick={() => handleReplaceImage(currentPreviewIndex)}
                                className="px-3 py-1 bg-green-500 text-white text-sm rounded hover:bg-green-600"
                              >
                                Replace
                              </button>
                              
                              {imagesToDelete.includes(currentPreviewIndex) ? (
                                <button 
                                  onClick={() => unmarkImageForDeletion(currentPreviewIndex)}
                                  className="px-3 py-1 bg-yellow-500 text-white text-sm rounded hover:bg-yellow-600"
                                >
                                  Undo Delete
                                </button>
                              ) : (
                                <button 
                                  onClick={() => markImageForDeletion(currentPreviewIndex)}
                                  className="px-3 py-1 bg-red-500 text-white text-sm rounded hover:bg-red-600"
                                >
                                  Delete
                                </button>
                              )}
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </form>
    </Form>
  );
}